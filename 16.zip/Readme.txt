---------------------------------------------Airline Management System ------------------------------------------------------------------------------------------------

Database name: airline_system

Tables:
* admin_info
* passenger_info
* booked_flights
* flights

ADMIN LOGIN DETAILS:
Username: admin
Passsword: admin

SAMPLE PASSENGER LOGIN DETAILS:
Username: testpass
Password: pass123

SAMPLE FLIGHT: Delhi-Mumbai has been included as a part of the database. 

Instructions to run the project:

1. Copy the 'ams' folder in your 'htdocs' folder located inside xampp.
2. In your web browser, type localhost/ams/  to open up the landing page of the website.
3. Follow the instructions displayed on the page to book or search flights.
4. Click on 'Login/Signup' to login/signup as a passenger or an admin and access the dashboard.


Note: 
* First time when the database gets created, only 1 flight Delhi-Mumbai is there. So, to add a new flight, login as
an admin (using above credentials), then go to "Add New flight" option.
* Only one admin is allowed for this system. So, you can signup only as a passenger and not as an admin.
* Please refer to the Project Video (link: https://www.youtube.com/watch?v=rYuS6akZEyg ) to see a demo of our project in case
you need any more instructions on setting up the project.


---------------------------------------------------THANK YOU ----------------------------------------------------------------------------------------------------------------