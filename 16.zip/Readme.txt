---------------------------------------------Airline Management System ------------------------------------------------------------------------------------------------

Database name: airline_system

Tables:
* admin_info
* booked_flights
* flights
* passenger_info

ADMIN LOGIN DETAILS (already inserted into the database):
Username: admin
Passsword: admin

Note: The database doesn't have any passenger record or a flight record already inserted into it.
So, you need to add a new flight by logging as admin (using above details) and then selecting the option "Add a new flight".
For creating a new passenger record, Signup as passenger by going to Login/Signup --> Passenger Login --> Signup option.

Instructions to run the project:

1. Copy the 'ams' folder in your 'htdocs' folder located inside xampp.
2. In your web browser, type localhost/ams/  to open up the landing page of the website.
3. Follow the instructions displayed on the page to book or search flights.
4. Click on 'Login/Signup' to login/signup as a passenger or an admin and access the dashboard.


Note: 
* Only one admin is allowed for this system. So, you can signup only as a passenger and not as an admin.
* Please refer to the Project Video (link: https://www.youtube.com/watch?v=rYuS6akZEyg ) to see a demo of our project in case
you need any more instructions on how to use any feature present on our website.


---------------------------------------------------THANK YOU ----------------------------------------------------------------------------------------------------------------